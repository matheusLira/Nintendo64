                  One Minute Left in The Second Period
                  --- ------ ---- -- --- ------ ------

                      OOOOOO  MM     MM   L
		      O	   O  M M   M M   L
                      O    O  M M   M M   L
                      O    O  M  M M  M   L
                      O    O  M   M   M   L
                      OOOOOO  M       M   LLLLL

     			    	 OML

                    http://www.oneminuteleft.com


 This game was downloaded from One Minute Left in The Second Period
page, if you downloaded it from a different page then send me an e-mail
and tell me (mwforetic@chile.crosswinds.net), so i can take legal
actions against the "linker" (linker means a webmaster copying my
links).

 Our purpose when distributing these games is to keep the classics from
lost over the time and not to break law. We aren't ignoring the
copyrights and the bussiness which owns them, our attempt is to bring its
deserved popularity to every one of these great games, we aren't trying
to make economical damages to Nintendo� or to any other gaming bussiness.

 Please read our Disclaimer for more legal info. 

                                                 HYPER SONIC  
                             One Minute Left in the Second Period's Webmaster
                                      
       